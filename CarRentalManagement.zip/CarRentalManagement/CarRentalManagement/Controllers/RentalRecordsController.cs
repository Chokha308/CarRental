﻿
using CarRentalManagement.Data;
using CarRentalManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarRentalManagement.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class rentalRecordsController : ControllerBase
    {
        private readonly DataContext _context;

        public rentalRecordsController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<RentalRecord>>> GetRentalRecords()
        {
            /*return await _context.RentalRecords.Include(r => r.Id).ToListAsync();*/
            return await _context.RentalRecords.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<RentalRecord>> GetRentalRecord(int id)
        {
            var rentalRecord = await _context.RentalRecords.FirstOrDefaultAsync(r => r.Id == id);
            if (rentalRecord == null)
            {
                return NotFound();
            }
            return rentalRecord;
        }

        [HttpPost]

        public async Task<ActionResult<RentalRecord>> PostRentalRecord(RentalRecord rentalRecord)
        {
            _context.RentalRecords.Add(rentalRecord);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetRentalRecord), new { id = rentalRecord.Id }, rentalRecord);

        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutRentalRecord(int id, RentalRecord rentalRecord)
        {
            if (id != rentalRecord.Id)
            {
                return BadRequest();
            }
            _context.Entry(rentalRecord).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RentalRecordExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteRentalRecord(int id)
        {
            var rentalRecord = await _context.RentalRecords.FindAsync(id);
            if (rentalRecord == null)
            {
                return NotFound();
            }

            _context.RentalRecords.Remove(rentalRecord);
            await _context.SaveChangesAsync();
            return NoContent();
        }


        private bool RentalRecordExists(int id)
        {
            return _context.RentalRecords.Any(e => e.Id == id);
        }
    }



}




