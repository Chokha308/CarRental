﻿using CarRentalManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CarRentalManagement.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
        public DbSet<Car> Cars { get; set; }
        public DbSet<RentalRecord> RentalRecords { get; set; }
    }
}

