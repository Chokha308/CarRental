﻿using CarRentalManagement.Data;
using CarRentalManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace CarRentalManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly DataContext _Context;
        public CarsController(DataContext context)
        {
            _Context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Car>>> GetCars()
        {
            return await _Context.Cars.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Car>> GetCar(int id)
        {
            var car = await _Context.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            return car;
        }

        [HttpPost]
        public async Task<ActionResult<Car>> postCar(Car car)
        {
            _Context.Cars.Add(car);
            await _Context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCar), new { id = car.Id }, car);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCar(int id, Car car)
        {

            if (id != car.Id)
            {
                return BadRequest();
            }

            _Context.Entry(car).State = EntityState.Modified;

            try
            {
                await _Context.SaveChangesAsync();
            }

            catch (DbUpdateConcurrencyException)
            {
                if (!CarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCar(int id)
        {
            var car = await _Context.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }

            _Context.Cars.Remove(car);
            await _Context.SaveChangesAsync();

            return NoContent();

        }

        private bool CarExists(int id)
        {
            return _Context.Cars.Any(e => e.Id == id);
        }
    }
}
