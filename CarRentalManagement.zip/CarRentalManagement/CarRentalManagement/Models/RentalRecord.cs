﻿namespace CarRentalManagement.Models
{
    public class RentalRecord
    {
        public int Id { get; set; }
        public int CarId { get; set; }
        public string RenterName { get; set; }
        public DateTime StartDate { get; set; } 
        public DateTime EndDate { get; set; }

        /*public Car Car { get; set; }*/
    }
}
